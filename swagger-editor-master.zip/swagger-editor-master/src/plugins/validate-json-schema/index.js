import Apis from "./apis"

export default function ValidateJsonSchemaPlugin() {
  return Apis
}
